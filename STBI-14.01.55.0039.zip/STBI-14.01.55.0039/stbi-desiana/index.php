<!DOCTYPE html>
<html>
	<head>
		<title>Information Retrieval Unisbank Semarang</title>
		<link rel="shortcut icon" href="img/icon musik.png"/>
		<link href="css/index.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div class="menu-wrap">
			<div class="menu">
				<header>
					<ul>
						<li><a href="upload.php" class="current">Upload File Pdf</a></li>
						<li><a href="Stemming.php">Pencarian Kata Dasar</a></li>
						<li><a href="query.php">Pencarian Query</a></li>
						<li><a href="hitungbobot.php">Hitung Bobot</a></li>
						<li><a href="hitungvektor.php">Hitung Vektor</a></li>
						
						<li><a href="awalquery.php">Tampilkan Cache</a></li>
						<li><a href="download.php">Download</a></li>
					</ul>
				</header>
			</div>
			</div>
		</div>

<div class="clearing"></div>
	<div class="header">
		<div class="logo">
			<h1><marquee>STBI-<span>SISTEM TEMU BALIK INFORMASI</span></marquee></font></h1>
		</div>
	</div>

	<div class="banner">
	<h1>Tugas Information Retrieval</font></h1>
	<h2>Universitas Stikubank Semarang</h2>
</div>

<div class="page">
	<div class="primary-col">
    <div class="generic">
		
		<div class="panel">
			<div class="title">
				<h1 align="center">CREATED BY</h1>
			</div>
			<div class="content" align="center"><img src="img/imgD.jpg" alt="mickey" width="250px" height="300px"/>
				<h2>Desiana Mirta Sari</h2>
					<p>14.01.55.0039</p>
					<p>Program Studi - Sistem Informasi</p>
					<p>Universitas Stikubank (UNISBANK) Semarang</p>
			</div>
		</div>
    </div>
	</div>
</div>
<!---page-end--->
<div class="clearing"></div>
<div class="primary-footer">
<div class="footer-wrap"></div>
	<div class="copyright-wrap">
		<div class="panel">
		<div class="content">
			<p>Copyright @Desiana Mirta Sari &copy; 2016 Sistem Informasi | Unisbank<br>
		</div>
		</div>
	</div>
</div>
<!--primary-footer-end--->
</body>
</html>
