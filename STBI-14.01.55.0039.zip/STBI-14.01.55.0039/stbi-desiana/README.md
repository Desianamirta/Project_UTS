#legal retrieval
