<html>
<head>
	<title>HitungBobot</title>
	<link href='images/icon.png' rel='shortcut icon'>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<style type="text/css">
			header, section, footer, aside, nav, article, figure, figcaption {
				display: block;}
			body {
				color: #000000;
				background-color: #f9f8f6;
				background-image: url("img/bckgrnd.jpg");
				background-position: center;
				font-family: Georgia, Times, serif;
				line-height: 1.4em;
				margin-left: 10%; margin-right: 10%;}
			.wrapper {
				width: 220px;
				margin: 20px auto 20px auto;
				border: 2px solid #000000;
				background-color: #ffffff;}
			header {
				height: 160px;
				background-image: url(images/U.png);}
			h1 {
				text-indent: -9999px;
				width: 940px;
				height: 130px;
				margin: 0px;}
			nav, footer {
				clear: both;
				color: #000000;
				background-color: #DC143C;
				height: 30px;}
			nav ul {
				margin: 0px;
				padding: 5px 0px 5px 30px;}
			nav li {
				display: inline;
				margin-right: 40px;}
			nav li a {
				color: #000000;}
			nav li a:hover, nav li a.current {
				color: #000000;}
			section.courses {
				float: left;
				width: 659px;
				border-right: 1px solid #eeeeee;}
			article {
				clear: both;
				overflow: auto;
				width: 100%;}
			hgroup {
				margin-top: 40px;}
			figure {
				float: left;
				width: 290px;
				height: 220px;
				padding: 5px;
				margin: 20px;
				border: 1px solid #eeeeee;}
			figcaption {
				font-size: 90%;
				text-align: left;}
			aside {
				width: 230px;
				float: left;
				padding: 0px 0px 0px 20px;}
			aside section a {
				display: block;
				padding: 10px;
				border-bottom: 1px solid #eeeeee;}
			aside section a:hover {
				color: #000000;
				background-color: #efefef;}
			a {
				color: #000000;
				text-decoration: none;}
			h1, h2, h3 {
				font-weight: normal;}
			h2 {
				margin: 10px 0px 5px 0px;
				padding: 0px;}
			h3 {
				margin: 0px 0px 10px 0px;
				color: #de6581;}
			aside h2 {
				padding: 30px 0px 10px 0px;
				color: #de6581;}
			footer {
				font-size: 80%;
				padding: 7px 0px 0px 20px;}
			.banner{width:940px; height:540px; margin-left:0px; margin:0 auto; margin-bottom:0px; background:url(images/Banner.jpg) no-repeat; position:relative;}
			.banner h1{ padding:10px; float:right; background:#C11B17; text-transform:uppercase; color:#ffffff;  font-size:30px; font-weight:normal; font-family: 'Blade Runner Movie Font'; position:absolute; top:130px; right:0;}
			.banner h2{ padding:10px; float:right; background:#ffffff; text-transform:uppercase; color:#1a202c;  font-size:22px; font-weight:normal; font-family: 'Baccarat'; position:absolute; top:195px; right:0;}
			img {
			 width: 100px;
			 height: 150px;
			 border: 4px solid #575D63;
			 padding: 10px;
			 margin: 20px;}
			keterangan {
			 text-align: left!important; /* Pilihan left center right */
			 bottom: 30px; /* Ukuran jarak dari bawah */
			 position: relative; /* Harus relative */
			 display: block; /* Harus block atau inline block */
			 padding: 5px 10px; /* Jarak Tulisan Dari Batas kotak tulisannya */
			 color: #fff; /* Warna Tulisan */
			 background-color: #000; /* Background Kotak Buat alternative */
			 background: rgba(0,0,0,0.4); /* Background transparan Secara Umum Pada Browser yg sdh mendukung */
			 font:Bold 12px arial; /* Besar Tulisan dan jenis huruf */
}			 
		</style>
		
</head>
<br>
<div align=Center>
<h2>Created By</h2>
<br>
<body>
<img class="gambar1" src="img/imgD.jpg" >
<pre>Desiana Mirta Sari</pre>
<pre>14.01.55.0039</pre>
</body>
</html>